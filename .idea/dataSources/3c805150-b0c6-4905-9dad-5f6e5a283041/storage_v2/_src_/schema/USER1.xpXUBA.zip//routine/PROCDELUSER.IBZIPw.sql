create procedure procDelUser(p_id IN TABLE_USER.ID%TYPE, p_res OUT INT)
is
    invalid_data exception;
  begin
    delete from TABLE_USER where ID = p_id;
    p_res := sql%rowcount;
    if sql%notfound or p_res = 0
    then
      rollback;
      raise invalid_data;
    end if;
    commit;
    exception
    when invalid_data
    then
      raise_application_error(-20001, 'Data tidak ditemukan');
    when others
    then
      raise_application_error(-20011, sqlerrm);
  end;
/

