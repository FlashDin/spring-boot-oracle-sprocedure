create procedure procFindAllUser(dataSets OUT SYS_REFCURSOR)
is
  begin
    open dataSets for select * from TABLE_USER;
    commit;
  end;
/

