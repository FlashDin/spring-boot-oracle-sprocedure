create procedure procFindUserById(p_id IN TABLE_USER.ID%TYPE, dataSets OUT SYS_REFCURSOR)
is
  begin
    open dataSets for select * from TABLE_USER where ID = p_id;
    commit;
  end;
/

