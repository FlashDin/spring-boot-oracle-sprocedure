create procedure procInsUser(p_username IN OUT TABLE_USER.USERNAME%TYPE,
                                        p_password IN OUT TABLE_USER.PASSWORD%TYPE,
                                        p_res      OUT    INT)
as
    invalid_data exception;
  begin
    insert into TABLE_USER (USERNAME, PASSWORD) values (p_username, p_password);
    p_res := sql%rowcount;
    if (p_res > 0)
    then
      select USERNAME, PASSWORD into p_username, p_password
      from TABLE_USER
      where ROWID in (select max(ROWID) from TABLE_USER);
    end if;
    commit;
    exception
    when invalid_data
    then
      raise_application_error(-20001, 'Data tidak ditemukan');
    when others
    then
      raise_application_error(-20011, sqlerrm);
  end;
/

