create procedure procUptUser(p_id       IN TABLE_USER.ID%TYPE,
                                        p_username IN TABLE_USER.USERNAME%TYPE,
                                        p_password IN TABLE_USER.PASSWORD%TYPE, p_res OUT INT) as
    invalid_data exception;
  begin
    update TABLE_USER
    set USERNAME = p_username,
        PASSWORD = p_password
    where ID = p_id;
    p_res := sql%rowcount;
    if sql%notfound or p_res = 0
    then
      rollback;
      raise invalid_data;
    end if;
    commit;
    exception
    when invalid_data
    then
      raise_application_error(-20001, 'Data tidak ditemukan');
    when others
    then
      raise_application_error(-20011, sqlerrm);
  end;
/

